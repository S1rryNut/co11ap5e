export default defineNuxtPlugin(() => {
  if (!import.meta.client || !('serviceWorker' in navigator)) return
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/admin-sw.js', { scope: '/admin/' }).catch(() => {})
  })
})
