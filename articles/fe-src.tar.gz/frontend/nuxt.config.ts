export default defineNuxtConfig({
  compatibilityDate: '2025-07-15',
  devtools: { enabled: true },
  css: ['~/assets/css/main.css'],
  runtimeConfig: {
    apiBase: process.env.NUXT_API_BASE || 'http://127.0.0.1:8080/api',
    public: {
      apiBase: process.env.NUXT_PUBLIC_API_BASE || '/api'
    }
  },
  app: {
    head: {
      htmlAttrs: { lang: 'zh-CN' },
      titleTemplate: '%s | Co11ap5e',
      meta: [
        { name: 'description', content: '个人博客、项目作品、简历与 AI 学习记录。' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        { name: 'theme-color', content: '#f5f6f2' },
        { property: 'og:type', content: 'website' },
        { property: 'og:site_name', content: 'Co11ap5e' },
        { property: 'og:title', content: 'Co11ap5e' },
        { property: 'og:description', content: '个人博客、项目作品、简历与 AI 学习记录。' },
        { property: 'og:image', content: 'https://co11ap5e.site/og-cover.png' },
        { property: 'og:url', content: 'https://co11ap5e.site/' },
        { name: 'twitter:card', content: 'summary' },
        { name: 'twitter:title', content: 'Co11ap5e' },
        { name: 'twitter:description', content: '个人博客、项目作品、简历与 AI 学习记录。' },
        { name: 'twitter:image', content: 'https://co11ap5e.site/og-cover.png' }
      ],
      link: [
        { rel: 'manifest', href: '/manifest.webmanifest' },
        { rel: 'icon', type: 'image/svg+xml', href: '/admin-icon.svg' },
        { rel: 'apple-touch-icon', href: '/admin-icon-192.png' }
      ]
    }
  },
  nitro: {
    compressPublicAssets: true
  }
})
