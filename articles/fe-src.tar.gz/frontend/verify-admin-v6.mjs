import { chromium } from 'playwright'

const browser = await chromium.launch({
  executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  headless: true
})
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } })
const page = await context.newPage()
const pageErrors = []

page.on('pageerror', error => pageErrors.push(error.message))
page.on('dialog', dialog => dialog.accept())

await page.goto('http://117.72.46.127/admin', { waitUntil: 'networkidle' })
await page.locator('input[type="password"]').fill(process.env.ADMIN_PASSWORD)
await page.locator('button[type="submit"]').click()
await page.locator('.admin-sidebar').waitFor({ state: 'visible' })

const sections = await page.locator('.admin-section-nav button').allInnerTexts()

await page.locator('.admin-section-nav button', { hasText: '游戏账号' }).click()
await page.getByRole('button', { name: '新建游戏账号' }).click()
await page.getByLabel('平台').fill('Smoke Test')
await page.getByLabel('账号昵称').fill('temporary-account')
await page.getByLabel('个人主页 URL').fill('https://example.com/smoke-account')
await page.getByLabel('介绍').fill('管理后台端到端测试数据')
await page.locator('.editor-actions button[type="submit"]').click()
await page.getByText('内容已保存。').waitFor()
const accountCreated = await page.locator('.admin-item-list', { hasText: 'Smoke Test' }).isVisible()
await page.locator('.editor-actions .danger').click()
await page.getByText('内容已删除。').waitFor()
const accountDeleted = await page.locator('.admin-item-list').getByText('Smoke Test').count() === 0

await page.locator('.admin-section-nav button', { hasText: '杂谈' }).click()
await page.getByRole('button', { name: '新建杂谈' }).click()
const talkCategory = await page.getByLabel('分类').inputValue()
const talkHasMarkdownEditor = await page.locator('.content-editor').isVisible()

await page.locator('.admin-section-nav button', { hasText: '简历' }).click()
const resumeName = await page.getByLabel('姓名').inputValue()
await page.screenshot({ path: '../artifacts/admin-v6-desktop.png', fullPage: true })

await page.locator('.logout-button').click()
await page.locator('.login-panel').waitFor({ state: 'visible' })

console.log(JSON.stringify({
  sections,
  accountCreated,
  accountDeleted,
  talkCategory,
  talkHasMarkdownEditor,
  resumeName,
  pageErrors
}, null, 2))

await browser.close()
