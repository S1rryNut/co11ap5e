<script setup lang="ts">
import { ArrowLeft, ChevronLeft, ChevronRight, Clock } from '@lucide/vue'

const route = useRoute()
const api = useSiteApi()
const { data: article, error } = await useAsyncData(`article-${route.params.slug}`, () => api.getArticle(String(route.params.slug)))

if (error.value) throw createError({ statusCode: 404, statusMessage: '文章不存在' })

const rendered = computed(() => useMarkdown(article.value?.content || ''))
const toc = computed(() => article.value ? useMarkdownToc(article.value.content) : [])
const { data: neighbors } = await useAsyncData(`article-neighbors-${route.params.slug}`, () => api.getArticleNeighbors(String(route.params.slug)))
const { data: related } = await useAsyncData(`article-related-${route.params.slug}`, () => api.getRelatedArticles(String(route.params.slug)))

const parentPage = computed(() => {
  if (article.value?.category === '杂谈') return { to: '/article/game', label: '返回游戏杂谈' }
  if (article.value?.category === 'AI 学习') return { to: '/article/ai', label: '返回人工智能' }
  return { to: '/article/tech', label: '返回技术文章' }
})

const siteUrl = 'https://co11ap5e.site'
const canonical = computed(() => `${siteUrl}/blog/${article.value?.slug}`)
const publishedAt = computed(() => article.value?.publishedAt || '')

useSeoMeta({
  title: () => article.value?.title || '文章',
  description: () => article.value?.excerpt || '',
  ogTitle: () => article.value?.title || '文章',
  ogDescription: () => article.value?.excerpt || '',
  ogType: 'article',
  ogUrl: canonical,
  ogSiteName: 'Co11ap5e',
  ogImage: `${siteUrl}/og-cover.png`,
  twitterCard: 'summary',
  twitterTitle: () => article.value?.title || '文章',
  twitterDescription: () => article.value?.excerpt || '',
  twitterImage: `${siteUrl}/og-cover.png`
})

useHead(() => ({
  link: [{ rel: 'canonical', href: canonical.value }],
  script: [{
    type: 'application/ld+json',
    innerHTML: JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: article.value?.title,
      description: article.value?.excerpt,
      datePublished: publishedAt.value,
      dateModified: publishedAt.value,
      mainEntityOfPage: canonical.value,
      author: { '@type': 'Person', name: 'Co11ap5e' },
      publisher: { '@type': 'Person', name: 'Co11ap5e' }
    })
  }]
}))
</script>

<template>
  <article v-if="article" class="article-page section-pad">
    <div class="article-container">
      <NuxtLink class="back-link" :to="parentPage.to"><ArrowLeft :size="17" /> {{ parentPage.label }}</NuxtLink>
      <header class="article-header">
        <p class="eyebrow">{{ article.category }}</p>
        <h1>{{ article.title }}</h1>
        <p>{{ article.excerpt }}</p>
        <div class="article-meta"><Clock :size="16" /> {{ article.readingMinutes }} 分钟阅读 · {{ new Date(article.publishedAt).toLocaleDateString('zh-CN') }}</div>
      </header>
      <nav v-if="toc.length" class="article-toc" aria-label="文章目录">
        <p class="article-toc-title">目录</p>
        <ol>
          <li v-for="item in toc" :key="item.id" :class="{ 'toc-h3': item.level === 3 }"><a :href="`#${item.id}`">{{ item.text }}</a></li>
        </ol>
      </nav>
      <div class="markdown-body" v-html="rendered" />

      <nav v-if="neighbors?.prev || neighbors?.next" class="article-pagination" aria-label="文章导航">
        <NuxtLink v-if="neighbors?.prev" class="paginate-link paginate-prev" :to="`/blog/${neighbors.prev.slug}`">
          <span><ChevronLeft :size="16" /> 上一篇</span>
          <strong>{{ neighbors.prev.title }}</strong>
        </NuxtLink>
        <NuxtLink v-if="neighbors?.next" class="paginate-link paginate-next" :to="`/blog/${neighbors.next.slug}`">
          <span>下一篇 <ChevronRight :size="16" /></span>
          <strong>{{ neighbors.next.title }}</strong>
        </NuxtLink>
      </nav>

      <section v-if="related?.length" class="related-articles" aria-label="相关文章">
        <h2>相关文章</h2>
        <div class="related-list">
          <NuxtLink v-for="item in related" :key="item.id" class="related-item" :to="`/blog/${item.slug}`">
            <div><span>{{ item.category }}</span><small>{{ item.readingMinutes }} 分钟</small></div>
            <h3>{{ item.title }}</h3>
            <p>{{ item.excerpt }}</p>
          </NuxtLink>
        </div>
      </section>
    </div>
  </article>
</template>
