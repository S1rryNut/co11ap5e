import type { ArticleSummary, GameEntry, Project } from '~/types'

const escapeXml = (value: string) => value.replace(/[<>&'\"]/g, char => ({
  '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;'
}[char] || char))

export default defineEventHandler(async (event) => {
  const config = useRuntimeConfig(event)
  const siteUrl = process.env.NUXT_SITE_URL || 'http://localhost:3000'
  let articles: ArticleSummary[] = []
  let projects: Project[] = []
  let games: GameEntry[] = []
  try { articles = await $fetch<ArticleSummary[]>('/public/articles', { baseURL: config.apiBase }) } catch {}
  try { projects = await $fetch<Project[]>('/public/projects', { baseURL: config.apiBase }) } catch {}
  try { games = await $fetch<GameEntry[]>('/public/games', { baseURL: config.apiBase }) } catch {}
  const paths = ['/', '/article/tech', '/article/game', '/article/ai', '/games', '/now', '/ai', '/projects', '/message', '/search',
    ...articles.map(item => `/blog/${item.slug}`), ...projects.map(item => `/projects/${item.slug}`),
    ...games.map(item => `/games/${item.slug}`)]
  setHeader(event, 'content-type', 'application/xml; charset=utf-8')
  return `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${paths.map(path => `<url><loc>${escapeXml(siteUrl + path)}</loc></url>`).join('')}</urlset>`
})
