import type { AiNewsItem, Article, ArticleNeighbors, ArticleSummary, GameAccount, GameEntry, LearningResource, NowProfile, Project, Resume, SearchResult } from '~/types'

export const useSiteApi = () => {
  const config = useRuntimeConfig()
  const baseURL = import.meta.server ? config.apiBase : config.public.apiBase

  const adminToken = () => import.meta.client ? sessionStorage.getItem('personal-site-admin-token') : ''
  const request = <T>(path: string, options: Parameters<typeof $fetch<T>>[1] = {}) => {
    const token = adminToken()
    return $fetch<T>(path, {
      baseURL,
      credentials: 'include',
      ...options,
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(options.headers as Record<string, string> || {})
      }
    })
  }

  return {
    getArticles: (query = '', category = '', excludeCategory = '') => {
      const params = new URLSearchParams()
      if (query) params.set('q', query)
      if (category) params.set('category', category)
      if (excludeCategory) params.set('excludeCategory', excludeCategory)
      const suffix = params.size ? `?${params.toString()}` : ''
      return request<ArticleSummary[]>(`/public/articles${suffix}`)
    },
    getArticle: (slug: string) => request<Article>(`/public/articles/${encodeURIComponent(slug)}`),
    getArticleNeighbors: (slug: string) => request<ArticleNeighbors>(`/public/articles/${encodeURIComponent(slug)}/adjacent`),
    getRelatedArticles: (slug: string) => request<ArticleSummary[]>(`/public/articles/${encodeURIComponent(slug)}/related`),
    getProjects: () => request<Project[]>('/public/projects'),
    getProject: (slug: string) => request<Project>(`/public/projects/${encodeURIComponent(slug)}`),
    getGames: () => request<GameEntry[]>('/public/games'),
    getGame: (slug: string) => request<GameEntry>(`/public/games/${encodeURIComponent(slug)}`),
    search: (query: string) => request<SearchResult[]>(`/public/search?q=${encodeURIComponent(query)}`),
    getAiNews: () => request<AiNewsItem[]>('/public/ai/news'),
    getLearningResources: () => request<LearningResource[]>('/public/ai/learning'),
    getResume: () => request<Resume>('/public/resume'),
    getGameAccounts: () => request<GameAccount[]>('/public/game-accounts'),
    getNowProfile: () => request<NowProfile>('/public/now'),
    request
  }
}
