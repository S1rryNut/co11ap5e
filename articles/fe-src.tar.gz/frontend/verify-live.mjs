import { chromium } from 'playwright'

const browser = await chromium.launch({
  executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  headless: true
})
const context = await browser.newContext({ viewport: { width: 390, height: 844 } })
const page = await context.newPage()
const errors = []

page.on('console', message => {
  if (message.type() === 'error') errors.push(message.text())
})
page.on('pageerror', error => errors.push(error.message))

const homeResponse = await page.goto('http://117.72.46.127/', { waitUntil: 'networkidle' })
await page.locator('.menu-button').click()
const mobileMenuVisible = await page.locator('.mobile-nav').isVisible()
const mobileMenuText = await page.locator('.mobile-nav').innerText()
await page.screenshot({ path: '../artifacts/home-mobile-v5.png', fullPage: true })

await page.goto('http://117.72.46.127/admin', { waitUntil: 'networkidle' })
const adminLoginVisible = await page.locator('.login-panel form').isVisible()
let adminLoginSucceeded = false
if (process.env.ADMIN_PASSWORD) {
  await page.locator('input[type="password"]').fill(process.env.ADMIN_PASSWORD)
  await page.locator('button[type="submit"]').click()
  await page.locator('.admin-sidebar').waitFor({ state: 'visible' })
  adminLoginSucceeded = true
  await page.locator('.logout-button').click()
  await page.locator('.login-panel').waitFor({ state: 'visible' })
}
await page.screenshot({ path: '../artifacts/admin-mobile-v5.png', fullPage: true })

await page.goto('http://117.72.46.127/resume', { waitUntil: 'networkidle' })
const resumeName = await page.locator('.resume-header h1').innerText()
const education = await page.locator('.resume-section').last().innerText()

console.log(JSON.stringify({
  homeStatus: homeResponse?.status(),
  csp: homeResponse?.headers()['content-security-policy'],
  mobileMenuVisible,
  mobileMenuText,
  adminLoginVisible,
  adminLoginSucceeded,
  resumeName,
  educationIncludesSchool: education.includes('浙大宁波理工学院'),
  errors
}, null, 2))

await browser.close()
