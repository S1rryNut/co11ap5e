<script setup lang="ts">
import { CheckCircle2, MessageSquareText, Send } from '@lucide/vue'

const api = useSiteApi()
const form = reactive({ name: '', email: '', content: '' })
const sending = ref(false)
const sent = ref(false)
const error = ref('')
const submit = async () => {
  sending.value = true; error.value = ''
  try {
    await api.request('/public/csrf')
    const cookie = document.cookie.split('; ').find(value => value.startsWith('XSRF-TOKEN='))
    if (!cookie) throw new Error('csrf')
    await api.request('/public/messages', { method: 'POST', headers: { 'X-XSRF-TOKEN': decodeURIComponent(cookie.slice('XSRF-TOKEN='.length)) }, body: form })
    sent.value = true; form.name = ''; form.email = ''; form.content = ''
  } catch { error.value = '提交失败，请稍后重试。' } finally { sending.value = false }
}
useSeoMeta({ title: '留言', description: '给 Co11ap5e 留言。' })
</script>

<template><div class="page-wrap section-pad"><header class="page-header content-wrap"><p class="eyebrow">Message</p><h1>给我留言</h1><p>项目交流、技术讨论或其他想说的话，都可以写在这里。</p></header><section class="content-wrap message-layout"><div class="message-intro"><MessageSquareText :size="30" /><h2>保持联系</h2><p>留言只会在管理后台中显示，不会公开展示你的姓名或邮箱。</p></div><form class="message-form" @submit.prevent="submit"><label>称呼<input v-model="form.name" required maxlength="80" autocomplete="name"></label><label>邮箱（可选）<input v-model="form.email" type="email" maxlength="200" autocomplete="email"></label><label>留言内容<textarea v-model="form.content" required maxlength="2000" rows="8" /></label><button class="primary-button" type="submit" :disabled="sending"><Send :size="17" />{{ sending ? '发送中' : '发送留言' }}</button><p v-if="sent" class="message-success"><CheckCircle2 :size="17" />留言已发送。</p><p v-if="error" class="form-message error-message">{{ error }}</p></form></section></div></template>
