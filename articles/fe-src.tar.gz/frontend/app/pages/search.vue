<script setup lang="ts">
import { ArrowUpRight, Search } from '@lucide/vue'

const route = useRoute()
const router = useRouter()
const api = useSiteApi()
const input = ref(String(route.query.q || ''))
const query = computed(() => String(route.query.q || '').trim())
const activeType = ref('ALL')
const { data: results, status } = await useAsyncData('search-results',
  () => query.value ? api.search(query.value) : Promise.resolve([]), { watch: [query] })

const labels = { ARTICLE: '文章', PROJECT: '项目', LEARNING: 'AI 学习', AI_NEWS: 'AI 热点', GAME: '游戏' }
const typeTabs = [{ key: 'ALL', label: '全部' }, ...Object.entries(labels).map(([key, label]) => ({ key, label }))]
const filteredResults = computed(() => activeType.value === 'ALL' ? results.value || [] : (results.value || []).filter(item => item.type === activeType.value))
const highlight = (value: string) => {
  const escaped = value.replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char] || char)
  if (!query.value) return escaped
  const term = query.value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  return escaped.replace(new RegExp(`(${term})`, 'gi'), '<mark>$1</mark>')
}
const submit = () => router.push({ path: '/search', query: input.value.trim() ? { q: input.value.trim() } : {} })

useSeoMeta({ title: '全站搜索', description: '搜索 Co11ap5e 的文章、项目、AI 学习和游戏档案。' })
</script>

<template>
  <div class="page-wrap section-pad search-page">
    <header class="page-header content-wrap"><p class="eyebrow">Search</p><h1>全站搜索</h1><p>文章、项目、AI 学习与游戏档案。</p></header>
    <section class="content-wrap search-content">
      <form class="site-search-form" @submit.prevent="submit">
        <Search :size="20" />
        <input v-model="input" type="search" maxlength="100" aria-label="搜索关键词" placeholder="输入关键词" autofocus>
        <button class="primary-button" type="submit"><Search :size="17" /> 搜索</button>
      </form>
      <p v-if="query" class="search-summary">“{{ query }}” · {{ filteredResults.length }} / {{ results?.length || 0 }} 条结果</p>
      <nav v-if="query && results?.length" class="search-type-tabs" aria-label="搜索结果类型"><button v-for="tab in typeTabs" :key="tab.key" type="button" :class="{ active: activeType === tab.key }" @click="activeType = tab.key">{{ tab.label }}</button></nav>
      <div v-if="status === 'pending'" class="empty-state">正在搜索...</div>
      <div v-else-if="filteredResults.length" class="search-results">
        <article v-for="result in filteredResults" :key="`${result.type}-${result.url}`">
          <a v-if="result.external" :href="result.url" target="_blank" rel="noreferrer">
            <div><span>{{ labels[result.type] }}</span><small>{{ result.meta }}</small></div><h2 v-html="highlight(result.title)" /><p v-html="highlight(result.summary)" /><ArrowUpRight :size="19" />
          </a>
          <NuxtLink v-else :to="result.url">
            <div><span>{{ labels[result.type] }}</span><small>{{ result.meta }}</small></div><h2 v-html="highlight(result.title)" /><p v-html="highlight(result.summary)" /><ArrowUpRight :size="19" />
          </NuxtLink>
        </article>
      </div>
      <p v-else-if="query" class="empty-state"><Search :size="19" /> 没有找到匹配内容。</p>
    </section>
  </div>
</template>
