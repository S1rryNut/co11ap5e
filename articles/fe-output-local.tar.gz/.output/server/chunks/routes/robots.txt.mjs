import { c as defineEventHandler, e as setHeader } from '../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const robots_txt = defineEventHandler((event) => {
  setHeader(event, "content-type", "text/plain; charset=utf-8");
  return "User-agent: *\nAllow: /\nDisallow: /admin\nSitemap: /sitemap.xml\n";
});

export { robots_txt as default };
//# sourceMappingURL=robots.txt.mjs.map
