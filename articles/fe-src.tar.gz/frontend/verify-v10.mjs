import { chromium } from 'playwright'

const base = 'http://117.72.46.127'
const browser = await chromium.launch({
  executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  headless: true
})
const errors = []
const watchErrors = page => {
  page.on('console', message => {
    if (message.type() === 'error' && !message.text().startsWith('Failed to load resource:')) errors.push(message.text())
  })
  page.on('pageerror', error => errors.push(error.message))
  page.on('response', response => {
    const expectedSessionCheck = response.status() === 403 && response.url().endsWith('/api/admin/auth/me')
    if (response.status() >= 400 && !expectedSessionCheck) errors.push(`${response.status()} ${response.url()}`)
  })
}

let temporaryArticleCreated = false
let temporaryGameCreated = false
try {
  const publicPage = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  publicPage.setDefaultTimeout(15_000)
  watchErrors(publicPage)
  await publicPage.goto(`${base}/`, { waitUntil: 'networkidle' })
  await publicPage.goto(`${base}/search?q=AI`, { waitUntil: 'networkidle' })
  await publicPage.getByRole('heading', { name: '全站搜索' }).waitFor()
  const searchResults = await publicPage.locator('.search-results article').count()
  if (searchResults < 1) throw new Error('全站搜索没有返回匹配内容')

  const admin = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  admin.setDefaultTimeout(15_000)
  watchErrors(admin)
  admin.on('dialog', dialog => dialog.accept())
  await admin.goto(`${base}/admin`, { waitUntil: 'domcontentloaded' })
  await admin.locator('input[type="password"]').fill(process.env.ADMIN_PASSWORD)
  await admin.locator('button[type="submit"]').click()
  await admin.locator('.admin-sidebar').waitFor()

  await admin.locator('.admin-section-nav button').filter({ hasText: /^博客$/ }).click()
  await admin.getByRole('button', { name: '新建博客' }).click()
  await admin.getByLabel('标题').fill('V10 临时版本一')
  await admin.getByLabel('固定链接', { exact: true }).fill('v10-temporary-article')
  await admin.getByLabel('摘要').fill('V10 自动验收临时文章')
  await admin.locator('#markdown-content').fill('# 版本一\n\nMarkdown 预览与本地草稿测试。')
  await admin.locator('.editor-mode-tabs button[title="预览"]').click()
  await admin.locator('.markdown-preview h1').filter({ hasText: '版本一' }).waitFor()
  await admin.waitForTimeout(1000)
  await admin.locator('.draft-status').waitFor()
  await admin.locator('.editor-mode-tabs button[title="双栏"]').click()
  await admin.locator('.editor-actions button[type="submit"]').click()
  await admin.getByText('内容已保存。').waitFor()
  temporaryArticleCreated = true
  await admin.getByLabel('标题').fill('V10 临时版本二')
  await admin.locator('#markdown-content').fill('# 版本二\n\n用于验证历史恢复。')
  await admin.locator('.editor-actions button[type="submit"]').click()
  await admin.getByText('内容已保存。').waitFor()
  const versionCount = await admin.locator('.version-list article').count()
  if (versionCount < 2) throw new Error(`文章历史版本不足: ${versionCount}`)
  await admin.locator('.version-list article').last().locator('button').click()
  await admin.getByText('历史版本已恢复。').waitFor()
  const restoredTitle = await admin.getByLabel('标题').inputValue()
  if (restoredTitle !== 'V10 临时版本一') throw new Error(`历史恢复内容错误: ${restoredTitle}`)
  await admin.locator('.editor-actions .danger').click()
  await admin.getByText('内容已删除。').first().waitFor()
  temporaryArticleCreated = false

  await admin.locator('.admin-section-nav button').filter({ hasText: /^游戏档案$/ }).click()
  await admin.getByRole('button', { name: '新建游戏档案' }).click()
  await admin.getByLabel('游戏名称').fill('V10 临时游戏')
  await admin.getByLabel('固定链接', { exact: true }).fill('v10-temporary-game')
  await admin.getByLabel('平台').fill('PC')
  await admin.getByLabel('一句话锐评').fill('仅用于端到端验收，完成后自动删除。')
  await admin.locator('.editor-actions button[type="submit"]').click()
  await admin.getByText('内容已保存。').waitFor()
  temporaryGameCreated = true
  const gameResponse = await publicPage.request.get(`${base}/api/public/games/v10-temporary-game`)
  if (!gameResponse.ok() || (await gameResponse.json()).title !== 'V10 临时游戏') throw new Error('公开游戏详情读取失败')
  await admin.locator('.editor-actions .danger').click()
  await admin.getByText('内容已删除。').first().waitFor()
  temporaryGameCreated = false

  await admin.locator('.admin-section-nav button').filter({ hasText: '访问统计' }).click()
  await admin.locator('.metrics-dashboard').waitFor()
  const viewsThirtyDays = Number(await admin.locator('.metrics-summary article').nth(1).locator('strong').innerText())
  if (viewsThirtyDays < 1) throw new Error('访问统计未记录页面访问')
  await admin.screenshot({ path: '../artifacts/admin-metrics-v10.png', fullPage: true })

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 } })
  mobile.setDefaultTimeout(15_000)
  watchErrors(mobile)
  for (const path of ['/games', '/search?q=AI']) {
    await mobile.goto(`${base}${path}`, { waitUntil: 'networkidle' })
    const overflow = await mobile.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth)
    if (overflow) throw new Error(`${path} 移动端存在横向溢出`)
  }
  await mobile.locator('.menu-button').click()
  await mobile.locator('.mobile-nav').waitFor()
  await mobile.screenshot({ path: '../artifacts/mobile-games-search-v10.png', fullPage: true })

  if (errors.length) throw new Error(`浏览器错误: ${errors.join(' | ')}`)
  console.log(JSON.stringify({ searchResults, versionCount, restoredTitle, viewsThirtyDays, mobileOverflow: false, browserErrors: 0 }))
} finally {
  if (temporaryArticleCreated || temporaryGameCreated) console.error('临时内容可能未清理，请检查后台。')
  await browser.close()
}
