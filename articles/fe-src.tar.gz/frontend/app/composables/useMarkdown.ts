import MarkdownIt from 'markdown-it'

export interface TocItem {
  level: number
  text: string
  id: string
}

interface MarkdownEnv {
  toc: TocItem[]
  usedIds: Record<string, number>
}

const renderer = new MarkdownIt({
  html: false,
  linkify: true,
  typographer: true
})

const stripInline = (text: string) => text.replace(/[*_`~#]/g, '').trim()

const slugify = (text: string) => {
  const base = stripInline(text).toLowerCase()
    .replace(/[^\p{L}\p{N}\s-]/gu, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
  return base || 'section'
}

// 给标题加锚点 id，同时把标题收集进 env.toc 供目录使用
renderer.renderer.rules.heading_open = (tokens: any, idx: number, options: any, env: any, self: any) => {
  const token = tokens[idx]
  const inline = tokens[idx + 1]
  const rawText = inline ? inline.content : ''
  let id = slugify(rawText)
  if (env && env.usedIds) {
    const count = env.usedIds[id] || 0
    env.usedIds[id] = count + 1
    if (count > 0) id = `${id}-${count + 1}`
  }
  token.attrSet('id', id)
  if (env && Array.isArray(env.toc)) {
    env.toc.push({ level: Number(token.tag.slice(1)), text: stripInline(rawText), id })
  }
  return self.renderToken(tokens, idx, options)
}

// 正文图片默认懒加载
const defaultImageRule = renderer.renderer.rules.image
renderer.renderer.rules.image = (tokens: any, idx: number, options: any, env: any, self: any) => {
  const token = tokens[idx]
  token.attrSet('loading', 'lazy')
  token.attrSet('decoding', 'async')
  return defaultImageRule ? defaultImageRule(tokens, idx, options, env, self) : self.renderToken(tokens, idx, options)
}

const makeEnv = (): MarkdownEnv => ({ toc: [], usedIds: {} })

export const useMarkdown = (source: string) => renderer.render(source || '', makeEnv())

export const useMarkdownToc = (source: string): TocItem[] => {
  const env = makeEnv()
  renderer.render(source || '', env)
  return env.toc
}
