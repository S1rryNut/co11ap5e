<script setup lang="ts">
import { Menu, Search, X } from '@lucide/vue'

const open = ref(false)
const route = useRoute()
watch(() => route.fullPath, () => { open.value = false })

const links = [
  { to: '/now', label: 'Now' },
  { to: '/article/tech', label: '文章' },
  { to: '/projects', label: '项目' },
  { to: '/games', label: '游戏' },
  { to: '/ai', label: 'Ai' },
  { to: '/message', label: '留言' }
]
const isLinkActive = (to: string) => {
  const path = route.path
  if (to === '/article/tech') return path === '/article/tech' || path.startsWith('/article/') || path === '/blog' || path.startsWith('/blog/') || path === '/talk' || path.startsWith('/talk/')
  if (to === '/ai') return path === '/ai' || path.startsWith('/ai/')
  return path === to || path.startsWith(`${to}/`)
}
</script>

<template>
  <header class="site-header">
    <div class="nav-wrap">
      <NuxtLink class="brand" to="/" aria-label="返回首页">
        <span class="brand-mark">Cls</span>
        <span>Co11ap5e</span>
      </NuxtLink>
      <div class="nav-actions">
        <nav class="desktop-nav" aria-label="主导航">
          <NuxtLink v-for="link in links" :key="link.to" :to="link.to" :class="{ 'nav-active': isLinkActive(link.to) }">{{ link.label }}</NuxtLink>
        </nav>
        <NuxtLink class="header-search" to="/search" aria-label="全站搜索" title="全站搜索"><Search :size="19" /></NuxtLink>
        <button class="icon-button menu-button" type="button" :aria-expanded="open" aria-label="切换导航" @click="open = !open">
          <X v-if="open" :size="20" />
          <Menu v-else :size="20" />
        </button>
      </div>
    </div>
    <nav v-if="open" class="mobile-nav" aria-label="移动端导航">
      <NuxtLink v-for="link in links" :key="link.to" :to="link.to" :class="{ 'nav-active': isLinkActive(link.to) }">{{ link.label }}</NuxtLink>
    </nav>
  </header>
</template>
