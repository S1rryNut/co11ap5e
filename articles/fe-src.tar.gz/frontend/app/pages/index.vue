<script setup lang="ts">
import { ArrowRight, BrainCircuit, Code2, FileText, MapPin, Terminal, Hammer, BookOpen, Gamepad2 } from '@lucide/vue'

const api = useSiteApi()
const projectName = (name: string) => name.includes('宁波市市民卡公司') ? '数据流转与确权平台' : name
const [{ data: articles }, { data: projects }, { data: news }, { data: now }, { data: games }] = await Promise.all([
  useAsyncData('home-articles', () => api.getArticles('', '', '杂谈')),
  useAsyncData('home-projects', () => api.getProjects()),
  useAsyncData('home-news', () => api.getAiNews()),
  useAsyncData('home-now', () => api.getNowProfile()),
  useAsyncData('home-games', () => api.getGames())
])

useSeoMeta({
  title: '首页',
  ogTitle: 'Co11ap5e | 开发者与 AI 学习者',
  ogDescription: '个人博客、项目作品、简历与 AI 学习记录。'
})
</script>

<template>
  <div>
    <section class="hero section-pad">
      <div class="content-wrap hero-grid">
        <div class="hero-copy">
          <p class="status-line"><Terminal :size="16" /> Co11ap5e / home</p>
          <h1>把想法做成<br><span class="hero-accent">可用的成果</span></h1>
          <p class="hero-lead">我是 Co11ap5e，主要做前端开发，也在补 Web 安全、密码学和 AI 应用开发。</p>
          <div class="hero-actions">
            <NuxtLink class="primary-button" to="/projects">查看我的成果 <ArrowRight :size="18" /></NuxtLink>
            <NuxtLink class="text-link" to="/article/tech">阅读文章</NuxtLink>
          </div>
        </div>
        <div class="profile-panel" aria-label="个人概览">
          <div class="profile-filebar"><FileText :size="16" /><span>profile / README.md</span></div>
          <div class="profile-summary">
            <div class="portrait-block" aria-hidden="true">Cls</div>
            <div><strong>Co11ap5e</strong><span>@Cls</span></div>
          </div>
          <p class="profile-bio">熟悉 Vue、React、Java 和前端安全，做过业务平台、个人工具和内容站点。</p>
          <dl class="quick-facts">
            <div><dt><MapPin :size="16" /> 所在地</dt><dd>江苏苏州</dd></div>
            <div><dt><Code2 :size="16" /> 方向</dt><dd>前端 / Web 安全</dd></div>
            <div><dt><BrainCircuit :size="16" /> 正在学习</dt><dd>RAG / Agent / Web 安全</dd></div>
          </dl>
          <p class="availability"><span /> 可接受新的合作与交流</p>
        </div>
      </div>
    </section>

    <section class="metric-band">
      <div class="content-wrap metrics">
        <div><strong>{{ projects?.length || 0 }}</strong><span>项项目成果</span></div>
        <div><strong>{{ articles?.length || 0 }}</strong><span>篇公开文章</span></div>
        <div><strong>{{ news?.length || 0 }}</strong><span>条 AI 动态</span></div>
      </div>
    </section>

    <section class="section-pad">
      <div class="content-wrap">
        <div class="section-heading">
          <div><p class="eyebrow">Selected work</p><h2>成果展示</h2></div>
          <NuxtLink class="text-link" to="/projects">全部项目 <ArrowRight :size="16" /></NuxtLink>
        </div>
        <div class="project-list home-project-list">
          <article v-for="(project, index) in projects?.slice(0, 3)" :key="project.id" class="project-row">
            <div class="project-number">{{ String(index + 1).padStart(2, '0') }}</div>
            <NuxtLink class="project-main" :to="`/projects/${project.slug}`"><p class="eyebrow">{{ project.featured ? 'Featured' : 'Project' }}</p><h2>{{ projectName(project.name) }}</h2><p>{{ project.summary }}</p><div class="tag-list"><span v-for="item in project.stack" :key="item">{{ item }}</span></div></NuxtLink>
          </article>
          <p v-if="!projects?.length" class="empty-state">项目成果正在整理中。</p>
        </div>
      </div>
    </section>

    <section class="section-pad alt-band">
      <div class="content-wrap split-section">
        <div class="section-intro"><p class="eyebrow">Next / Now</p><h2>近期计划</h2><p>{{ now?.headline || '持续构建、学习和记录。' }}</p><NuxtLink class="text-link" to="/now">查看完整 Now <ArrowRight :size="16" /></NuxtLink></div>
        <div class="news-stack home-plan-list">
          <div v-for="item in now?.building?.slice(0, 3)" :key="item" class="news-line"><span class="source-dot" /><div><small>正在构建</small><strong>{{ item }}</strong></div><Hammer :size="17" /></div>
          <div v-for="item in games?.filter(game => game.status === 'PLAYING').slice(0, 3)" :key="`game-${item.id}`" class="news-line"><span class="source-dot" /><div><small>正在游玩</small><strong>{{ item.title }}</strong></div><Gamepad2 :size="17" /></div>
          <div v-for="item in now?.learning?.slice(0, 2)" :key="`learn-${item}`" class="news-line"><span class="source-dot" /><div><small>正在学习</small><strong>{{ item }}</strong></div><BookOpen :size="17" /></div>
          <div v-if="!now?.building?.length && !now?.learning?.length" class="empty-state">近期计划正在整理中。</div>
        </div>
      </div>
    </section>

    <section class="section-pad">
      <div class="content-wrap">
        <div class="section-heading">
          <div><p class="eyebrow">Writing</p><h2>最近文章</h2></div>
          <NuxtLink class="text-link" to="/article/tech">查看全部 <ArrowRight :size="16" /></NuxtLink>
        </div>
        <div class="article-list">
          <ArticleRow v-for="article in articles?.slice(0, 3)" :key="article.id" :article="article" />
          <p v-if="!articles?.length" class="empty-state">文章正在整理中。</p>
        </div>
      </div>
    </section>

    <section class="section-pad alt-band">
      <div class="content-wrap split-section">
        <div class="section-intro">
          <p class="eyebrow">AI Notebook</p>
          <h2>追踪变化，沉淀理解</h2>
          <p>从官方信息源提取值得关注的动态，并把零散信息整理成可复习的学习路径。</p>
          <NuxtLink class="primary-button" to="/article/ai">查看 AI 文章 <ArrowRight :size="18" /></NuxtLink>
        </div>
        <div class="news-stack">
          <a v-for="item in news?.slice(0, 3)" :key="item.id" :href="item.sourceUrl" target="_blank" rel="noreferrer" class="news-line">
            <span class="source-dot" />
            <div><small>{{ item.sourceName }}</small><strong>{{ item.title }}</strong></div>
            <ArrowRight :size="17" />
          </a>
          <div v-if="!news?.length" class="empty-state"><FileText :size="20" /> AI 信息源将在后台同步后显示。</div>
        </div>
      </div>
    </section>
  </div>
</template>
