import { chromium } from 'playwright'

const browser = await chromium.launch({
  executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  headless: true
})
const errors = []
const watchErrors = page => {
  page.on('console', message => {
    if (message.type() === 'error' && !message.text().startsWith('Failed to load resource:')) errors.push(message.text())
  })
  page.on('pageerror', error => errors.push(error.message))
  page.on('response', response => {
    const expectedSessionCheck = response.status() === 403 && response.url().endsWith('/api/admin/auth/me')
    if (response.status() >= 400 && !expectedSessionCheck) errors.push(`${response.status()} ${response.url()}`)
  })
}

try {
  const desktop = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  desktop.setDefaultTimeout(15_000)
  watchErrors(desktop)
  await desktop.goto('http://117.72.46.127/projects', { waitUntil: 'networkidle' })
  const citizenCardLink = desktop.getByRole('link', { name: /宁波市市民卡公司签名确权平台/ })
  await citizenCardLink.click()
  await desktop.waitForURL('**/projects/ningbo-citizen-card-rights-confirmation')
  for (const heading of ['项目背景', '我的职责', '业务流程', '技术架构', '工程亮点', '项目复盘']) {
    await desktop.getByRole('heading', { name: heading }).waitFor()
  }
  const workflowCount = await desktop.locator('.case-workflow li').count()
  const highlightCount = await desktop.locator('.case-highlights li').count()
  if (workflowCount !== 4 || highlightCount !== 4) throw new Error('案例结构数量不符合预期')
  await desktop.screenshot({ path: '../artifacts/project-case-desktop-v9.png', fullPage: true })

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 } })
  mobile.setDefaultTimeout(15_000)
  watchErrors(mobile)
  await mobile.goto('http://117.72.46.127/projects/distributed-certificate-storage', { waitUntil: 'networkidle' })
  await mobile.getByRole('heading', { name: '分布式证书存储系统' }).waitFor()
  const overflow = await mobile.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth)
  if (overflow) throw new Error('项目案例移动端存在横向溢出')
  await mobile.screenshot({ path: '../artifacts/project-case-mobile-v9.png', fullPage: true })

  const admin = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  admin.setDefaultTimeout(15_000)
  watchErrors(admin)
  await admin.goto('http://117.72.46.127/admin', { waitUntil: 'domcontentloaded' })
  await admin.locator('input[type="password"]').fill(process.env.ADMIN_PASSWORD)
  await admin.locator('button[type="submit"]').click()
  await admin.locator('.admin-sidebar').waitFor()
  await admin.locator('.admin-section-nav button').filter({ hasText: /^项目$/ }).click()
  await admin.locator('.admin-item-list button').filter({ hasText: '宁波市市民卡公司签名确权平台' }).click()
  const slug = await admin.getByLabel('固定链接').inputValue()
  const workflow = await admin.getByLabel('业务流程（每行一步）').inputValue()
  const highlights = await admin.getByLabel('工程亮点（每行一项）').inputValue()
  if (slug !== 'ningbo-citizen-card-rights-confirmation' || !workflow || !highlights) {
    throw new Error('后台案例字段未正确读取')
  }
  await admin.screenshot({ path: '../artifacts/admin-project-case-v9.png', fullPage: true })

  if (errors.length) throw new Error(`浏览器错误: ${errors.join(' | ')}`)
  console.log(`project case: ${workflowCount} workflow steps, ${highlightCount} highlights`)
  console.log('mobile overflow: false')
  console.log(`admin project slug: ${slug}`)
  console.log('browser console: clean')
} finally {
  await browser.close()
}
