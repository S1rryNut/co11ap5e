<script setup lang="ts">
import { GitFork as Github, Mail, Rss } from '@lucide/vue'
</script>

<template>
  <footer class="site-footer">
    <div class="footer-inner">
      <div>
        <strong>Co11ap5e</strong>
        <p>记录构建、学习和持续思考。</p>
      </div>
      <div class="footer-links">
        <a href="mailto:2801039176@qq.com" aria-label="电子邮箱" title="电子邮箱"><Mail :size="18" /></a>
        <a href="https://github.com" target="_blank" rel="noreferrer" aria-label="GitHub" title="GitHub"><Github :size="18" /></a>
        <a href="/rss.xml" aria-label="RSS" title="RSS"><Rss :size="18" /></a>
      </div>
    </div>
    <div class="footer-meta">© {{ new Date().getFullYear() }} Co11ap5e · 内容保留署名权</div>
  </footer>
</template>
