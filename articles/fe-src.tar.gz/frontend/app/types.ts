export interface ArticleSummary {
  id: number
  slug: string
  title: string
  excerpt: string
  category: string
  tags: string[]
  publishedAt: string
  readingMinutes: number
}

export interface Article extends ArticleSummary {
  content: string
}

export interface ArticleNeighbors {
  prev: ArticleSummary | null
  next: ArticleSummary | null
}

export interface ArticleVersion extends Article {
  articleId: number
  createdAt: string
  published: boolean
}

export interface Project {
  id: number
  slug: string
  name: string
  summary: string
  stack: string[]
  background: string
  responsibility: string
  workflow: string[]
  architecture: string
  highlights: string[]
  retrospective: string
  repositoryUrl?: string
  liveUrl?: string
  featured: boolean
  sortOrder?: number
}

export interface GameAccount {
  id: number
  platform: string
  handle: string
  url: string
  description: string
  sortOrder: number
}

export interface GameEntry {
  id: number
  slug: string
  title: string
  coverUrl?: string
  platform: string
  status: 'PLAYING' | 'COMPLETED' | 'WISHLIST' | 'DROPPED' | 'LIBRARY'
  score?: number
  hoursPlayed: number
  completedOn?: string
  verdict: string
  reviewArticleSlug?: string
  sortOrder: number
}

export interface SearchResult {
  type: 'ARTICLE' | 'PROJECT' | 'LEARNING' | 'AI_NEWS' | 'GAME'
  title: string
  summary: string
  url: string
  meta: string
  external: boolean
}

export interface PageMetric {
  path: string
  views: number
  averageRenderMs: number
  maxRenderMs: number
}

export interface DailyMetric {
  date: string
  views: number
}

export interface MetricsSummary {
  viewsToday: number
  viewsThirtyDays: number
  averageRenderMs: number
  topPages: PageMetric[]
  dailyViews: DailyMetric[]
}

export interface Message {
  id: number
  name: string
  email?: string
  content: string
  createdAt: string
}

export interface AiNewsItem {
  id: number
  title: string
  summary: string
  sourceName: string
  sourceUrl: string
  publishedAt: string
  topics: string[]
}

export interface LearningResource {
  id: number
  title: string
  description: string
  level: 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED'
  topic: string
  url?: string
  sortOrder: number
}

export interface Resume {
  displayName: string
  headline: string
  location: string
  email: string
  summary: string
  skills: string[]
  experiences: Array<{
    organization: string
    role: string
    period: string
    description: string
  }>
  education: Array<{
    institution: string
    major: string
    period: string
  }>
}

export interface NowProfile {
  headline: string
  updatedAt: string
  building: string[]
  learning: string[]
  playing: string[]
  reading: string[]
}
