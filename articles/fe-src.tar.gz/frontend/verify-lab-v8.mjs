import { chromium } from 'playwright'

const browser = await chromium.launch({
  executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  headless: true
})

const errors = []

try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  page.setDefaultTimeout(15_000)
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()) })
  page.on('pageerror', error => errors.push(error.message))
  await page.goto('http://117.72.46.127/lab', { waitUntil: 'networkidle' })
  await page.getByRole('heading', { name: '项目实验室' }).waitFor()

  await page.getByLabel('输入').fill('abc')
  await page.getByRole('button', { name: '计算' }).click()
  const sha256 = await page.locator('.lab-result code').first().innerText()
  if (sha256 !== 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad') throw new Error('SHA-256 结果错误')

  await page.getByRole('button', { name: 'JSON', exact: true }).click()
  await page.getByLabel('输入').fill('{"name":"Cls","ok":true}')
  await page.getByRole('button', { name: '格式化' }).click()
  const formatted = await page.getByLabel('输出').inputValue()
  if (!formatted.includes('\n  "name": "Cls"')) throw new Error('JSON 格式化结果错误')

  await page.getByRole('button', { name: '证书', exact: true }).click()
  await page.getByLabel('PEM').fill('-----BEGIN CERTIFICATE-----\nYWJj\n-----END CERTIFICATE-----')
  await page.getByRole('button', { name: '检查' }).click()
  await page.getByText('CERTIFICATE', { exact: true }).waitFor()
  const fingerprint = await page.locator('.certificate-result code').innerText()
  if (!fingerprint.startsWith('BA:78:16:BF')) throw new Error('PEM 指纹结果错误')

  await page.getByRole('button', { name: 'Prompt 对比', exact: true }).click()
  await page.getByLabel('版本 A').fill('system\nuser')
  await page.getByLabel('版本 B').fill('system\nuser\ncontext')
  await page.getByText('3 行', { exact: true }).waitFor()
  await page.screenshot({ path: '../artifacts/lab-desktop-v8.png', fullPage: true })

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 } })
  mobile.on('console', message => { if (message.type() === 'error') errors.push(message.text()) })
  mobile.on('pageerror', error => errors.push(error.message))
  await mobile.goto('http://117.72.46.127/lab', { waitUntil: 'networkidle' })
  await mobile.getByRole('button', { name: '切换导航' }).click()
  const links = await mobile.locator('.mobile-nav a').allInnerTexts()
  if (!links.includes('实验室')) throw new Error('移动端导航缺少实验室')
  await mobile.screenshot({ path: '../artifacts/lab-mobile-v8.png', fullPage: true })

  if (errors.length) throw new Error(`浏览器错误: ${errors.join(' | ')}`)
  console.log('SHA-256, JSON, PEM, Prompt interactions passed')
  console.log(`mobile navigation: ${links.join(', ')}`)
  console.log('browser console: clean')
} finally {
  await browser.close()
}
