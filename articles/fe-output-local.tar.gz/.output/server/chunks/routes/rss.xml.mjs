import { c as defineEventHandler, u as useRuntimeConfig, e as setHeader } from '../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const xml = (value) => value.replace(/[<>&'\"]/g, (char) => ({
  "<": "&lt;",
  ">": "&gt;",
  "&": "&amp;",
  "'": "&apos;",
  '"': "&quot;"
})[char] || char);
const rss_xml = defineEventHandler(async (event) => {
  const config = useRuntimeConfig(event);
  const siteUrl = process.env.NUXT_SITE_URL || "http://localhost:3000";
  const articles = (await $fetch("/public/articles", { baseURL: config.apiBase })).filter((item) => item.category !== "\u6742\u8C08");
  setHeader(event, "content-type", "application/rss+xml; charset=utf-8");
  return `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>Co11ap5e \u7684\u535A\u5BA2</title><link>${xml(siteUrl)}</link><description>\u8F6F\u4EF6\u5F00\u53D1\u3001\u9879\u76EE\u5B9E\u8DF5\u4E0E AI \u5B66\u4E60\u8BB0\u5F55</description>${articles.map((item) => `<item><title>${xml(item.title)}</title><link>${xml(`${siteUrl}/blog/${item.slug}`)}</link><description>${xml(item.excerpt)}</description><pubDate>${new Date(item.publishedAt).toUTCString()}</pubDate><guid>${xml(`${siteUrl}/blog/${item.slug}`)}</guid></item>`).join("")}</channel></rss>`;
});

export { rss_xml as default };
//# sourceMappingURL=rss.xml.mjs.map
