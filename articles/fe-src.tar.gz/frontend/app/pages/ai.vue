<script setup lang="ts">
import { ArrowRight, ArrowUpRight, BrainCircuit, Radio, Route } from '@lucide/vue'

const api = useSiteApi()
const [{ data: news }, { data: resources }] = await Promise.all([
  useAsyncData('ai-news', () => api.getAiNews()),
  useAsyncData('ai-learning', () => api.getLearningResources())
])
const levelLabel = { BEGINNER: '入门', INTERMEDIATE: '进阶', ADVANCED: '深入' }
useSeoMeta({ title: 'AI 总览', description: '近期 AI 动态与学习路线。' })
</script>

<template>
  <div class="page-wrap">
    <header class="page-header section-pad content-wrap ai-header">
      <div><p class="eyebrow">AI / Overview</p><h1>人工智能</h1><p>追踪可信信息源，整理学习路径，并把理解沉淀为可复用的文章。</p><NuxtLink class="primary-button" to="/article/ai">阅读人工智能文章 <ArrowRight :size="17" /></NuxtLink></div>
      <div class="ai-index"><div><BrainCircuit :size="17" /> 学习与实践</div><div><Radio :size="17" /> 近期动态</div><div><Route :size="17" /> 结构化路线</div></div>
    </header>
    <section class="section-pad content-wrap">
      <div class="section-heading"><div><p class="eyebrow">Signals</p><h2>近期 AI 动态</h2></div><span class="update-note">来源聚合 · 保留原文链接</span></div>
      <div class="news-grid"><a v-for="item in news" :key="item.id" class="news-item" :href="item.sourceUrl" target="_blank" rel="noreferrer"><div class="news-item-meta"><span>{{ item.sourceName }}</span><ArrowUpRight :size="16" /></div><h3>{{ item.title }}</h3><p>{{ item.summary }}</p><div class="news-item-footer"><span>{{ new Date(item.publishedAt).toLocaleDateString('zh-CN') }}</span></div></a><p v-if="!news?.length" class="empty-state">暂无 AI 动态。</p></div>
    </section>
    <section class="section-pad alt-band"><div class="content-wrap learning-layout"><div class="sticky-intro"><p class="eyebrow">Learning path</p><h2>AI 工程学习路线</h2><p>从基础概念到工程实践，按阶段记录正在学习的内容。</p></div><ol class="learning-list"><li v-for="(item, index) in resources" :key="item.id"><span class="step-number">{{ String(index + 1).padStart(2, '0') }}</span><div><small>{{ levelLabel[item.level] || item.level }} · {{ item.topic }}</small><h3>{{ item.title }}</h3><p>{{ item.description }}</p></div><a :href="item.url" target="_blank" rel="noreferrer" title="打开学习资源"><ArrowUpRight :size="17" /></a></li><li v-if="!resources?.length" class="empty-state">学习路线正在整理中。</li></ol></div></section>
  </div>
</template>
