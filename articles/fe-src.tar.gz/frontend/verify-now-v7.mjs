import { chromium } from 'playwright'

const browser = await chromium.launch({
  executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  headless: true
})

try {
  const desktop = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  desktop.setDefaultTimeout(15_000)
  await desktop.goto('http://117.72.46.127/now', { waitUntil: 'networkidle' })
  await desktop.getByRole('heading', { name: '此时此刻' }).waitFor()
  const groups = await desktop.locator('.now-group h2').allInnerTexts()
  await desktop.screenshot({ path: '../artifacts/now-desktop-v7.png', fullPage: true })
  console.log(`desktop Now: ${groups.join(', ')}`)

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 } })
  mobile.setDefaultTimeout(15_000)
  await mobile.goto('http://117.72.46.127/now', { waitUntil: 'networkidle' })
  await mobile.getByRole('button', { name: '切换导航' }).click()
  await mobile.locator('.mobile-nav').waitFor()
  const mobileLinks = await mobile.locator('.mobile-nav a').allInnerTexts()
  if (!mobileLinks.includes('Now')) throw new Error('移动端导航缺少 Now')
  await mobile.screenshot({ path: '../artifacts/now-mobile-menu-v7.png', fullPage: true })
  console.log(`mobile navigation: ${mobileLinks.join(', ')}`)

  const admin = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  admin.setDefaultTimeout(15_000)
  await admin.goto('http://117.72.46.127/admin', { waitUntil: 'domcontentloaded' })
  await admin.locator('input[type="password"]').fill(process.env.ADMIN_PASSWORD)
  await admin.locator('button[type="submit"]').click()
  await admin.locator('.admin-sidebar').waitFor()
  const sections = await admin.locator('.admin-section-nav button').allInnerTexts()
  if (sections.length !== 8 || !sections.includes('Now')) {
    throw new Error(`后台分区不符合预期: ${sections.join(', ')}`)
  }
  await admin.locator('.admin-section-nav button').filter({ hasText: /^Now$/ }).click()
  await admin.getByRole('heading', { name: '编辑 Now' }).waitFor()
  await admin.waitForFunction(() => {
    const headline = document.querySelector('.now-editor-fields textarea')
    const date = document.querySelector('.now-editor-fields input[type="date"]')
    return headline?.value && date?.value
  })
  const headline = await admin.getByLabel('当前状态').inputValue()
  const updatedAt = await admin.getByLabel('更新日期').inputValue()
  if (!headline || !updatedAt) throw new Error('Now 表单未读取到初始数据')
  await admin.screenshot({ path: '../artifacts/admin-now-v7.png', fullPage: true })
  console.log(`admin sections: ${sections.join(', ')}`)
  console.log(`admin Now loaded: ${updatedAt}, ${headline.length} chars`)
} finally {
  await browser.close()
}
