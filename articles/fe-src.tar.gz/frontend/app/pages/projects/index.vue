<script setup lang="ts">
import { ArrowRight, ArrowUpRight, GitFork as Github } from '@lucide/vue'

const api = useSiteApi()
const { data: projects } = await useAsyncData('projects', () => api.getProjects())
const projectName = (name: string) => name.includes('宁波市市民卡公司') ? '数据流转与确权平台' : name
useSeoMeta({ title: '项目', description: '个人项目与工程实践。' })
</script>

<template>
  <div class="page-wrap section-pad">
    <header class="page-header content-wrap"><p class="eyebrow">Projects</p><h1>项目与实践</h1><p>从问题出发，记录设计、实现与迭代过程。</p></header>
    <section class="content-wrap project-list">
      <article v-for="(project, index) in projects" :key="project.id" class="project-row">
        <div class="project-number">{{ String(index + 1).padStart(2, '0') }}</div>
        <NuxtLink class="project-main" :to="`/projects/${project.slug}`"><p class="eyebrow">{{ project.featured ? 'Featured Case' : 'Project Case' }}</p><h2>{{ projectName(project.name) }}</h2><p>{{ project.summary }}</p><p class="project-role">{{ project.responsibility.split('\n').find(Boolean) }}</p><div class="tag-list"><span v-for="item in project.stack" :key="item">{{ item }}</span></div><span class="project-detail-link">查看完整案例 <ArrowRight :size="16" /></span></NuxtLink>
        <div class="project-links">
          <a v-if="project.repositoryUrl" :href="project.repositoryUrl" target="_blank" rel="noreferrer" title="查看代码"><Github :size="19" /></a>
          <a v-if="project.liveUrl" :href="project.liveUrl" target="_blank" rel="noreferrer" title="访问项目"><ArrowUpRight :size="19" /></a>
        </div>
      </article>
      <p v-if="!projects?.length" class="empty-state">项目内容正在整理中。</p>
    </section>
  </div>
</template>
