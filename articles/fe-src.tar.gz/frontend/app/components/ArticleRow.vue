<script setup lang="ts">
import { ArrowUpRight } from '@lucide/vue'
import type { ArticleSummary } from '~/types'

defineProps<{ article: ArticleSummary }>()

const date = (value: string) => new Intl.DateTimeFormat('zh-CN', {
  year: 'numeric', month: 'short', day: 'numeric'
}).format(new Date(value))
</script>

<template>
  <NuxtLink class="article-row" :to="`/blog/${article.slug}`">
    <div class="article-date">{{ date(article.publishedAt) }}</div>
    <div class="article-copy">
      <div class="eyebrow">{{ article.category }} · {{ article.readingMinutes }} 分钟</div>
      <h3>{{ article.title }}</h3>
      <p>{{ article.excerpt }}</p>
      <div class="tag-list">
        <span v-for="tag in article.tags" :key="tag">#{{ tag }}</span>
      </div>
    </div>
    <ArrowUpRight class="row-arrow" :size="20" />
  </NuxtLink>
</template>
