import { chromium } from 'playwright'

const browser = await chromium.launch({
  executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  headless: true
})

try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } })
  page.setDefaultTimeout(15_000)
  console.log('1: browser started')

  await page.goto('http://117.72.46.127/admin', { waitUntil: 'domcontentloaded' })
  await page.locator('.login-panel').waitFor()
  console.log('2: login page ready')

  await page.locator('input[type="password"]').fill(process.env.ADMIN_PASSWORD)
  await page.locator('button[type="submit"]').click()
  await page.locator('.admin-sidebar').waitFor()
  console.log('3: login succeeded')

  const sections = await page.locator('.admin-section-nav button').allInnerTexts()
  console.log(`4: sections ${sections.join(', ')}`)

  await page.locator('.admin-section-nav button', { hasText: '游戏账号' }).click()
  await page.getByRole('button', { name: '新建游戏账号' }).click()
  await page.getByLabel('平台').fill('Smoke Test')
  await page.getByLabel('账号昵称').fill('temporary-account')
  await page.getByLabel('个人主页 URL').fill('https://example.com/smoke-account')
  await page.getByLabel('介绍').fill('管理后台端到端测试数据')
  await page.locator('.editor-actions button[type="submit"]').click()
  await page.getByText('内容已保存。').waitFor()
  console.log('5: game account created')

  page.once('dialog', dialog => dialog.accept())
  await page.locator('.editor-actions .danger').click()
  await page.getByText('内容已删除。').waitFor()
  console.log('6: game account deleted')

  await page.locator('.admin-section-nav button', { hasText: '杂谈' }).click()
  await page.getByRole('button', { name: '新建杂谈' }).click()
  const talkCategory = await page.getByLabel('分类').inputValue()
  await page.locator('input[type="file"]').setInputFiles({
    name: 'smoke-test.md',
    mimeType: 'text/markdown',
    buffer: Buffer.from('# Markdown upload test\n\nTemporary content.')
  })
  const markdownUploaded = (await page.locator('.content-editor').inputValue()).includes('Markdown upload test')
  console.log(`7: talk editor ready (${talkCategory}), markdown uploaded: ${markdownUploaded}`)

  await page.locator('.admin-section-nav button', { hasText: '简历' }).click()
  const resumeName = await page.getByLabel('姓名').inputValue()
  await page.screenshot({ path: '../artifacts/admin-v6-desktop.png', fullPage: true })
  console.log(`8: resume ready (${resumeName})`)

  await page.locator('.logout-button').click()
  await page.locator('.login-panel').waitFor()
  console.log('9: logout succeeded')
} finally {
  await browser.close()
}
